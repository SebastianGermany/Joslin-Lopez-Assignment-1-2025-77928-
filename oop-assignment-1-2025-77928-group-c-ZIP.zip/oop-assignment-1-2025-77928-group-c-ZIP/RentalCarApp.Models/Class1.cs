﻿namespace RentalCarApp.Models
{
    public class Class1
    {

    }
}
